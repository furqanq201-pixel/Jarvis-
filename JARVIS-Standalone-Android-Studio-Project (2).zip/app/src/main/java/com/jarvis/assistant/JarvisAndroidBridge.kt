package com.jarvis.assistant

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import java.util.Locale

class JarvisAndroidBridge(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isTtsReady = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            tts?.setPitch(0.95f)
            isTtsReady = true
        }
    }

    @JavascriptInterface
    fun isStandaloneApk(): Boolean = true

    @JavascriptInterface
    fun speak(text: String, speechRate: Float) {
        if (!isTtsReady) return
        tts?.setSpeechRate(speechRate)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt_${System.currentTimeMillis()}")
    }

    @JavascriptInterface
    fun stopSpeaking() {
        tts?.stop()
    }

    @JavascriptInterface
    fun hasPermission(permission: String): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            context.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    @JavascriptInterface
    fun executeSystemAction(action: String, payloadJson: String): String {
        if (action == "haptic_pulse") {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
            }
            return "{\"status\":\"ok\"}"
        }
        return "{\"status\":\"ok\",\"action\":\"$action\"}"
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
