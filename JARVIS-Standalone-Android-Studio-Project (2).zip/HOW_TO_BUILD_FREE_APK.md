# JARVIS — 100% Free Standalone Android APK Project
Zero Cloud Run · Zero Subscriptions · Zero Paid Services · No Google Play Store Required

This Android Studio / Kotlin project contains your complete JARVIS personal assistant:
- Full JARVIS Mobile UI, Chat, History, Short-Term Session Memory, Long-Term Memory Vault, Reminders, and Settings pre-bundled inside `app/src/main/assets/`.
- 100% Free On-Device Native Android Voice Output (`android.speech.tts.TextToSpeech`) & Microphone Voice Input.
- Researcher, Innovative, Industrial, and Romantic cognitive persona addressing you as "Sir".
- Standalone On-Device Cognitive Brain that works offline with zero external servers.

## Free Method 1: Build APK Locally in Android Studio (Free on Windows / Mac / Linux)
1. Unzip this folder (`JARVIS-Standalone-Android-Studio`).
2. Open **Android Studio** (100% free from developer.android.com) and select **Open** -> choose this unzipped folder.
3. Wait for Gradle Sync to finish, then click **Build > Build Bundle(s) / APK(s) > Build APK(s)** in the top menu.
4. Click **locate** in the bottom-right notification to find `app/build/outputs/apk/debug/app-debug.apk`.
5. Copy `app-debug.apk` to your Android phone via USB, Bluetooth, or Google Drive and tap it to install directly!

## Free Method 2: Build APK Automatically in the Cloud via GitHub Actions (No PC / No Android Studio Needed)
1. Create a free repository on GitHub and upload the contents of this unzipped folder.
2. Go to the **Actions** tab in your GitHub repository and click **Build Free Standalone JARVIS Android APK** -> **Run workflow**.
3. In ~2 minutes, download `JARVIS-Standalone-Android-APK.zip` from the workflow's **Artifacts** section directly on your Android phone, unzip it, and tap `app-debug.apk` to install!
